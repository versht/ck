k = open("o.txt","r").readlines()
lm = []

for line in k:
  s = line.strip()
  m = s.split("|")
  h = {
        "Email": m[0],
        "Password": m[1]
   }
  b = lm.append(h)

import json
with open('data1.json', 'w', encoding='utf-8') as f:
    json.dump(lm, f, ensure_ascii=False, indent=4)
#open("an.json","a").write("{}".format(lm))
print (lm)
