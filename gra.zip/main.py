import requests
import time
from bs4 import BeautifulSoup as bs
# ANSI color codes for formatting
BOLD_YELLOW = "\033[1;33m"
RED = "\033[31m"
GREEN = "\033[32m"
RESET = "\033[0m"

def check_proxy(proxy):
    """
    Check if the proxy is working by sending a request to a test URL.
    Returns a tuple: (is_live, speed).
    """
    test_url = "http://httpbin.org/ip"  # A simple test endpoint
    proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
    try:
        start_time = time.time()
        response = requests.get(test_url, proxies=proxies, timeout=5)  # Adjust timeout as needed
        elapsed_time = time.time() - start_time
        if response.status_code == 200:
            return True, round(elapsed_time, 2)
    except Exception:
        return False, None
    return False, None

def process_proxies(proxies, live_file):
    """
    Check the provided proxies and categorize them into live or dead lists.
    """
    live_proxies = []

    for proxy in proxies:
        proxy = proxy.strip()
        if proxy:
            print(f"Checking proxy: {proxy}")
            is_live, speed = check_proxy(proxy)
            if is_live:
                print(f"{GREEN}[ForestArmy] Live proxy: {proxy} (Speed: {speed} seconds){RESET}")
                live_proxies.append(f"http://{proxy}")
            else:
                print(f"{RED}[ForestArmy] Dead proxy: {proxy}{RESET}")

    # Write live proxies to live_file
    with open(live_file, "w") as outfile:
        outfile.write("\n".join(live_proxies))

    print(f"\n{BOLD_YELLOW}=== ForestArmy Proxy Checker Results ==={RESET}")
    print(f"{GREEN}Total live proxies: {len(live_proxies)}{RESET}")
    print(f"{BOLD_YELLOW}Proxy checking completed successfully. Keep using ForestArmy for your projects!{RESET}")

def get_proxies_from_user():
    """
    Allow the user to paste proxies manually.
    """
    print(f"{BOLD_YELLOW}Enter your proxies (one per line). Type 'done' to finish.{RESET}")
    proxies = []
    while True:
        proxy = input("> ").strip()
        if proxy.lower() == "done":
            break
        if proxy:
            proxies.append(proxy)
    return proxies


def get_free_proxies():
    url = "https://free-proxy-list.net/"
    soup = bs(requests.get(url).content, "html.parser")
    proxies = []
    for row in soup.find("table").find_all("tr")[1:]:
        tds = row.find_all("td")
        try:
            ip = tds[0].text.strip()
            port = tds[1].text.strip()
            host = f"{ip}:{port}"
            proxies.append(host)
        except IndexError:
            continue
    return proxies

if __name__ == "__main__":

#    choice = input("Enter your choice (1 or 2): ").strip()
    choice = "2"
    if choice == "1":
        proxies = get_proxies_from_user()
    elif choice == "2":
        kontol = get_free_proxies()
    else:
        print(f"{RED}Invalid choice. Exiting...{RESET}")
        exit()

    # File names for output
    live_file = "proxy_list.txt"    # Output file for live proxies

    process_proxies(kontol, live_file)
