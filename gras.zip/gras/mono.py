import requests

filename = "proxy.txt"

response = requests.get("https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/all.txt")
content = response.text
with open(filename, 'w') as f:
  f.write(content)
