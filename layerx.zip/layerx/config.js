export const config = {
  ref_code: "Vomc4tcB",
  num_ref: 100, // number of references
};