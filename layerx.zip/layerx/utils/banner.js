const banner = `TOOL SHARED BY FORESTARMY Thanks To Team Airdrop Hunter Toc`;
export default banner;
