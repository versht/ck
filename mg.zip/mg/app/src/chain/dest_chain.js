export class BRIDGE {
    static ["MANGOBSC"] = "USDT(bscTest)";
    static ["MANGOETH"] = 'USDT(ethTest)';
  }