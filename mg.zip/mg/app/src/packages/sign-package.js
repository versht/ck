export const SIGNPACKAGE = {
    'ADDRESS': "0xfc6f2fdbb08a821f64d0a77e95bcddfd11d1eab95e1d9f50b8cc277ded7cf72d",
    'MODULE': {
      'SIGN': {
        'SIGNPOOL': "0x2f876388acb6fcde3cc5f486cf3540409c5d560b5419c4f2a86da51d6f6efb49",
        'CLOCK': "0x6"
      }
    }
  };