export const BEINGDEXPACKAGE = {
    'ADDRESS': "0x7f683d74b5f8b533f68e93732fd0a06a527fc4e0bc9c59a6e040f8c2e0462d44",
    'MODULE': {
      'CLOB': {
        'AIUSDTPOOL': '0xf5e672757fd4f0da1883085e3b51d74cd91597856e1f22a130bcc7c4d84380c6'
      }
    }
  };