/**
 * Accounts list file
 * write your accounts like this
 * export const accountLists = [
 *     "MANGOPRIVKEY1",
 *     "MANGOPRIVKEY2",
 *     "MANGOPRIVKEY3",
 * ];
 *
 */

export const accountList = [
     "mgoprivkey1qpr7yvrllhyv0wq70mml2lj2t99rwzw75el0fkhz4c48tz7h0em9q3dzz3p",
     "mgoprivkey1qqd6h50hzvaeqs7qyx9440d9wyqzgaynju8ktyn4ujs8u0zuhgz6sheuxn9"
];
