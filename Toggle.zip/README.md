# ini gw edit .bat dan bash .sh jadi index supaya kalian yang awam ga pusing
# Disclaimer

This project includes code that is related to encryption. By using this code, you acknowledge the following:

- The encryption methods and algorithms implemented here are provided for educational purposes only. 
- The author does not take any responsibility for any misuse or unintended consequences that may arise from the use of this code.
- It is your responsibility to ensure that you understand the implications of using encryption and to comply with all applicable laws and regulations in your jurisdiction.
- Always conduct thorough testing and validation of any encryption code before deploying it in a production environment.

Use this code at your own risk.
Register Airdrop : https://toggle.pro/sign-up/90733d3f-1ca0-4f8e-b886-f5b04c213582
# HOW TO RUN SCRIPT 
![image](https://github.com/user-attachments/assets/629f3350-f32f-411b-bba0-669590295e98)

```
git clone https://github.com/AirdropFamilyIDN-V2-0/Toggle.git
```
```
cd Toggle
```
```
npm i user-agents axios colors p-limit https-proxy-agent socks-proxy-agent crypto ws uuid pako moment lodash
```
```
node index.js
```

Datas.txt isi dengan set-cookie: contoh copy sampai bawah jangan copy vary:

![image](https://github.com/user-attachments/assets/9279ef3e-16cd-498c-90fe-52415687fbab) 

Suprort Multi Akun 
set-cookie: 1
set-cookie: 2
set-cookie: 3
proxies isi dengan proxymu contoh 
```
http://user:password@host:port
https://user:password@host:port
socks4://user:password@host:port
socks5://user:password@host:port
```
