
a = open("proxy.txt").read().splitlines()

def splitList(lst,lgh):
    return [lst[y*lgh:lgh*(y+1)] for y in range(-(len(lst)//-lgh))]
lis = splitList(a,len(a)//2)

with open("pro1.txt", "w") as txt_file:
    for line in lis[0]:
        txt_file.write("".join(line) + "\n")
with open("pro2.txt", "w") as txt_file:
    for line in lis[1]:
        txt_file.write("".join(line) + "\n")
